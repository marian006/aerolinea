class equipaje{
    constructor(peso){
        this.peso=peso;
    }
}