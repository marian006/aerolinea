class vuelo {
    costructor(destino, origen, precio, pasajeros){
        this.destino=destino;
        this.origen=origen;
        this.precio=precio;
        this.pasajeros=pasajeros;
    }
}