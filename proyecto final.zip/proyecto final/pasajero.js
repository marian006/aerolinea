class pasajero{
    constructor(numero_maletas, nombre, apellido, telefono){
        this.numero_maletas=numero_maletas;
        this.nombre=nombre;
        this.apellido=apellido;
        this.telefono=telefono;
    }
}